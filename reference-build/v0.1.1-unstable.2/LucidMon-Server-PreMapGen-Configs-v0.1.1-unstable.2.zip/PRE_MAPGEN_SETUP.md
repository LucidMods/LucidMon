# LucidMon pre-mapgen server setup — v0.1.1-unstable.2

Install the JAR in `mods/` and place the `config/` directory from this archive at the server root.

LucidMon will also create these files automatically if they do not exist:

- `config/LucidMon/LucidMon_core.JSON5`
- `config/LucidMon/MapGen/LucidMon_mapgen.JSON5`

It will never overwrite an existing copy.

## Important unstable.2 limitation

This is a **MapGen pre-flight build**. The full absolute-coordinate Kanto terrain generator is not active yet.

- `STANDARD` is safe and leaves normal world generation untouched.
- `KANTO_ARCHIPELAGO` is fully represented in config and validated, but **do not create the final Kanto world with unstable.2**.
- A future generator-enabled build will consume the same config schema.

The file `LucidMon_mapgen-KANTO_ARCHIPELAGO-FUTURE.JSON5` is provided as the Kanto-selected version for the generator-enabled build. When that build arrives, copy/rename it to:

`config/LucidMon/MapGen/LucidMon_mapgen.JSON5`

## Before the final Kanto world is created

1. Stop the server.
2. Install the generator-enabled LucidMon build.
3. Set `mapType: "KANTO_ARCHIPELAGO"`.
4. Review the Kanto profile coordinates, biome manifest, route graph, Mt. Moon, volcano island, starting BCA city, and world-border settings.
5. Keep all gym coordinates at their placeholders until after you inspect the generated terrain.
6. Make sure the intended final world folder does **not** already exist.
7. Start the server and let that generator-enabled build create the world from scratch.
8. Run `/lucidmon mapgen audit-biomes` after generation/scan and human-review the profile before calling it final.

## Current pre-flight commands

- `/lucidmon mapgen status`
- `/lucidmon mapgen validate`
- `/lucidmon mapgen preflight`
- `/lucidmon config validate`
- `/lucidmon config reload`

`/lucidmon mapgen audit-biomes` is reserved but will not run until the Kanto generator itself is enabled.

## Other LucidMon module configs

No other file is required **before terrain generation** in this build.

- Map Reveal currently uses Minecraft storage/functions rather than a disk JSON5 file.
- Soulpack currently has no separate disk config.
- Virtual Pasture retains its existing PastureLoot configuration behavior; it is unrelated to initial world generation.
